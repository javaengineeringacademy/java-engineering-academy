# Module 09: Multithreading

> **Difficulty:** ⭐⭐⭐⭐ Advanced  
> **Reading:** 40 min | **Practice:** 60 min | **Total:** 100 min

## Overview
Single-threaded applications can't use multiple CPUs, block on I/O, and offer poor responsiveness. Java's multithreading capabilities let you execute tasks concurrently, keep applications responsive under load, and utilize all available hardware. This module covers thread creation, synchronization, executor services, concurrent collections, and virtual threads.

## Learning Objectives
- Create threads using Thread, Runnable, and virtual threads
- Prevent race conditions using synchronized blocks, locks, and atomic variables
- Configure thread pools with ExecutorService for scalable task execution
- Use CompletableFuture to compose asynchronous operations
- Identify and diagnose deadlocks, starvation, and other concurrency bugs

## Prerequisites
- OOP concepts
- Exception handling
- Basic JVM knowledge

## History
- **1995** — Java 1.0 introduced `Thread` class and `Runnable` interface
- **1998** — Java 1.2 added `Timer` and `TimerTask`
- **2001** — Java 1.3 added `java.util.concurrent` package (Doug Lea)
- **2004** — Java 5 added `ExecutorService`, `Lock`, `Semaphore`, `CountDownLatch`, `CyclicBarrier`, `ConcurrentHashMap`
- **2004** — Java 5 added `java.util.concurrent.atomic` package
- **2011** — Java 7 added `ForkJoinPool`, `Phaser`
- **2014** — Java 8 added `CompletableFuture`, `parallelStream()`
- **2017** — Java 9 added `Flow` API (reactive streams)
- **2021** — Java 19 added virtual threads (Project Loom, preview)
- **2023** — Java 21 made virtual threads a standard feature

## Why This Concept Exists
Single-threaded applications:
- Can't use multiple CPUs
- Block on I/O
- Poor responsiveness

Multithreading provides:
- Parallel execution
- Better responsiveness
- Resource utilization
- Asynchronous processing

## Problem Statement
How do you execute multiple tasks concurrently while managing shared resources?

## Core Concepts

### Thread States

```mermaid
stateDiagram-v2
    [*] --> NEW: new Thread()
    NEW --> RUNNABLE: start()
    RUNNABLE --> BLOCKED: waiting for monitor lock
    BLOCKED --> RUNNABLE: acquired lock
    RUNNABLE --> WAITING: wait(), join(), LockSupport.park()
    WAITING --> RUNNABLE: notify(), notifyAll(), unpark()
    RUNNABLE --> TIMED_WAITING: sleep(ms), wait(ms), join(ms)
    TIMED_WAITING --> RUNNABLE: timeout, notify(), unpark()
    RUNNABLE --> TERMINATED: run() completes
    TERMINATED --> [*]
    
    state RUNNABLE {
        [*] --> Ready
        Ready --> Running: scheduler dispatch
        Running --> Ready: yield/preemption
    }
```

| State | Description |
|-------|-------------|
| NEW | Created but not started |
| RUNNABLE | Executing or ready |
| BLOCKED | Waiting for lock |
| WAITING | Waiting indefinitely |
| TIMED_WAITING | Waiting with timeout |
| TERMINATED | Completed |

### Synchronization Mechanisms

| Mechanism | Description |
|-----------|-------------|
| synchronized | Method/block locking |
| volatile | Visibility guarantee |
| Lock | Explicit locking |
| Semaphore | Permit-based |
| CountDownLatch | One-time barrier |
| CyclicBarrier | Reusable barrier |

## Internal Working

### Thread Creation
```
Thread.start() → JVM creates OS thread → run() executes
```

### Monitor Lock
```
Object: [Monitor Lock] [Entry Queue] [Wait Queue]
  ↓
Thread A: [Holds Lock] → executes
Thread B: [Waits in Entry Queue]
Thread C: [Waits in Wait Queue]
```

## JVM Perspective

### Thread Implementation
- 1:1 mapping to OS threads
- Thread stack (default 512KB-1MB)
- Thread-local storage
- Context switching cost

### Memory Model
- Happens-before relationship
- Memory visibility
- Atomic operations
- volatile semantics

## Architecture Diagram

```mermaid
graph TD
    A[Java Concurrency] --> B[Thread]
    A --> C[Synchronization]
    A --> D[ExecutorService]
    A --> E[Concurrent Collections]
    
    B --> F[Thread Class]
    B --> G[Runnable Interface]
    
    C --> H[synchronized]
    C --> I[Lock]
    C --> J[volatile]
    
    D --> K[ThreadPool]
    D --> L[ScheduledExecutor]
    
    E --> M[ConcurrentHashMap]
    E --> N[CopyOnWriteArrayList]
```

## Syntax

### Thread Creation
```java
// Extending Thread
class MyThread extends Thread {
    @Override
    public void run() {
        System.out.println("Thread running");
    }
}

// Implementing Runnable
class MyRunnable implements Runnable {
    @Override
    public void run() {
        System.out.println("Runnable running");
    }
}

// Lambda
Thread t = new Thread(() -> System.out.println("Lambda thread"));
t.start();
```

### Synchronization
```java
// Synchronized method
public synchronized void increment() {
    count++;
}

// Synchronized block
public void update() {
    synchronized (this) {
        count++;
    }
}

// Volatile
private volatile boolean running = true;
```

### ExecutorService Types

```mermaid
graph TB
    subgraph ExecutorHierarchy["ExecutorService Hierarchy"]
        Executor["Executor<br/>(execute Runnable)"]
        ExecutorService["ExecutorService<br/>(submit Callable/Future)"]
        ScheduledExecutor["ScheduledExecutorService<br/>(delayed/periodic tasks)"]
        
        Executor --> ExecutorService
        ExecutorService --> ScheduledExecutor
    end
    
    subgraph Implementations["Common Implementations"]
        direction TB
        Fixed["FixedThreadPool<br/>Fixed number of threads"]
        Cached["CachedThreadPool<br/>Creates as needed, reuses idle"]
        Single["SingleThreadExecutor<br/>Single worker thread"]
        Scheduled["ScheduledThreadPool<br/>Core pool for scheduling"]
        ForkJoin["ForkJoinPool<br/>Work-stealing algorithm"]
    end
    
    ExecutorService --> Fixed
    ExecutorService --> Cached
    ExecutorService --> Single
    ScheduledExecutor --> Scheduled
    ForkJoin -.->|"extends"| ExecutorService
    
    style Fixed fill:#e8f5e9
    style Cached fill:#e3f2fd
    style Single fill:#fff3e0
    style Scheduled fill:#f3e5f5
    style ForkJoin fill:#e0f7fa
```

### ExecutorService Usage

```java
// Thread pool
ExecutorService executor = Executors.newFixedThreadPool(4);
executor.submit(() -> System.out.println("Task 1"));
executor.submit(() -> System.out.println("Task 2"));
executor.shutdown();

// CompletableFuture
CompletableFuture<String> future = CompletableFuture
    .supplyAsync(() -> "Hello")
    .thenApply(s -> s + " World");
System.out.println(future.get());
```

## Easy Example
```java
public class EasyExample {
    public static void main(String[] args) throws InterruptedException {
        Thread t = new Thread(() -> {
            for (int i = 0; i < 5; i++) {
                System.out.println("Thread: " + i);
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        });
        
        t.start();
        t.join(); // Wait for thread to finish
        System.out.println("Main thread finished");
    }
}
```

## Medium Example
```java
import java.util.concurrent.*;

public class MediumExample {
    private static int counter = 0;
    private static final Object lock = new Object();
    
    public static void main(String[] args) throws Exception {
        ExecutorService executor = Executors.newFixedThreadPool(10);
        CountDownLatch latch = new CountDownLatch(100);
        
        for (int i = 0; i < 100; i++) {
            executor.submit(() -> {
                synchronized (lock) {
                    counter++;
                }
                latch.countDown();
            });
        }
        
        latch.await();
        System.out.println("Counter: " + counter);
        executor.shutdown();
    }
}
```

## Hard Example
```java
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

public class HardExample {
    // ReadWriteLock
    private static final ReadWriteLock rwLock = new ReentrantReadWriteLock();
    private static final Map<String, String> cache = new HashMap<>();
    
    public static String get(String key) {
        rwLock.readLock().lock();
        try {
            return cache.get(key);
        } finally {
            rwLock.readLock().unlock();
        }
    }
    
    public static void put(String key, String value) {
        rwLock.writeLock().lock();
        try {
            cache.put(key, value);
        } finally {
            rwLock.writeLock().unlock();
        }
    }
    
    // Atomic operations
    private static final AtomicInteger atomicCounter = new AtomicInteger(0);
    
    public static void main(String[] args) throws Exception {
        ExecutorService executor = Executors.newFixedThreadPool(10);
        
        for (int i = 0; i < 1000; i++) {
            executor.submit(() -> atomicCounter.incrementAndGet());
        }
        
        executor.shutdown();
        executor.awaitTermination(1, TimeUnit.SECONDS);
        System.out.println("Atomic counter: " + atomicCounter.get());
    }
}
```

## Enterprise Example
```java
import java.util.concurrent.*;
import java.util.*;

public class EnterpriseExample {
    // Custom thread pool
    public static ExecutorService createPool() {
        return new ThreadPoolExecutor(
            4, 8, 60L, TimeUnit.SECONDS,
            new LinkedBlockingQueue<>(100),
            new ThreadPoolExecutor.CallerRunsPolicy()
        );
    }
    
    // Async processing
    public static CompletableFuture<List<String>> processAsync(List<String> items) {
        return CompletableFuture.supplyAsync(() -> {
            return items.stream()
                .parallel()
                .map(item -> processItem(item))
                .toList();
        });
    }
    
    private static String processItem(String item) {
        return item.toUpperCase();
    }
    
    public static void main(String[] args) throws Exception {
        ExecutorService executor = createPool();
        
        List<CompletableFuture<String>> futures = List.of(
            CompletableFuture.supplyAsync(() -> "Task1", executor),
            CompletableFuture.supplyAsync(() -> "Task2", executor),
            CompletableFuture.supplyAsync(() -> "Task3", executor)
        );
        
        CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
        
        futures.forEach(f -> System.out.println(f.join()));
        executor.shutdown();
    }
}
```

## Performance Considerations
- Thread creation is expensive
- Use thread pools
- Minimize synchronization
- Use concurrent collections
- Avoid thread-unsafe operations

## Time & Space Complexity

| Operation | Time | Space |
|-----------|------|-------|
| Thread creation | O(1) | O(stack) |
| Lock acquire | O(1) | O(1) |
| Context switch | O(1) | O(1) |
| ThreadPool submit | O(1) | O(queue) |

## Thread Safety
- Synchronized blocks
- Volatile fields
- Atomic variables
- Immutable objects
- Thread-local storage

## Best Practices
1. Use thread pools
2. Minimize lock scope
3. Use concurrent collections
4. Prefer atomic variables
5. Handle interrupts properly

## Common Mistakes
1. Race conditions
2. Deadlocks
3. Starvation
4. Thread-unsafe collections

## Comparison Table

| Mechanism | Use Case | Performance |
|-----------|----------|-------------|
| synchronized | Simple locking | Good |
| Lock | Flexible locking | Good |
| volatile | Visibility | Fast |
| Atomic | Simple operations | Fast |

## Interview Questions

### Q1: What is the difference between Thread and Runnable?
**Answer:** Thread is a class, Runnable is an interface. Prefer Runnable for flexibility.

### Q2: What is a deadlock?
**Answer:** Two threads waiting for each other's locks.

### Q3: What is the difference between synchronized and Lock?
**Answer:** synchronized is implicit, Lock is explicit with more features.

### Q4: What is a thread pool?
**Answer:** Reusable collection of threads for executing tasks.

### Q5: What is CompletableFuture?
**Answer:** Future that supports composition and chaining.

### Q6: What is the volatile keyword?
**Answer:** Guarantees visibility of changes across threads.

### Q7: What is an atomic variable?
**Answer:** Variable with lock-free thread-safe operations.

### Q8: What is CountDownLatch?
**Answer:** One-time synchronization barrier.

### Q9: What is CyclicBarrier?
**Answer:** Reusable synchronization barrier.

### Q10: What is the difference between wait and sleep?
**Answer:** wait releases lock, sleep doesn't.

### Q11: What is interrupt?
**Answer:** Signal to stop thread execution.

### Q12: What is daemon thread?
**Answer:** Background thread that doesn't prevent JVM shutdown.

### Q13: What is ThreadLocal?
**Answer:** Variable with per-thread values.

### Q14: What is the Fork/Join framework?
**Answer:** Framework for divide-and-conquer parallelism.

### Q15: What is the difference between Executor and ExecutorService?
**Answer:** ExecutorService adds lifecycle management.

## Exercises

### Easy
1. Create and start a thread
2. Use synchronized block
3. Implement Runnable

### Medium
1. Create thread pool
2. Use CompletableFuture
3. Implement producer-consumer

### Hard
1. Implement custom lock
2. Create thread-safe cache
3. Build work-stealing pool

## Summary
Multithreading enables concurrent execution. Use synchronization and concurrency utilities for thread safety.

## References
- Oracle Java Documentation: Concurrency
- Java Concurrency in Practice
- Baeldung Concurrency Guide

## Cross-References

- **Previous Module:** [08 - I/O and NIO](../08-io-nio/)
- **Next Module:** [10 - JVM Internals](../10-jvm-internals/)
- **Related:** [02 - OOP](../02-oop/) — synchronized methods, object monitors
- **Related:** [04 - Collections](../04-collections/) — thread-safe collections
- **Related:** [07 - Functional Programming](../07-functional-programming/) — CompletableFuture and Stream API
- **Related:** [10 - JVM Internals](../10-jvm-internals/) — thread model, memory model
- **External:** [Oracle Java Concurrency Tutorial](https://docs.oracle.com/javase/tutorial/essential/concurrency/)
- **External:** [Java Concurrency in Practice](https://jcip.net/)

## Prerequisites

- [OOP](../02-oop/README.md)

## Debugging Tips

| Problem | Tool/Technique | How |
|---------|---------------|-----|
| Deadlock detection | `jstack <pid>` or JConsole | Look for "BLOCKED" threads with circular lock dependencies |
| Race condition identification | Thread sanitizer / stress tests | Run concurrent tests repeatedly; use `Thread.sleep()` to amplify timing issues |
| Thread pool exhaustion | JMX monitoring + thread dumps | Monitor `activeCount`, `queueSize`; capture dumps when pool is saturated |
| Memory leak from ThreadLocal | Heap dump + MAT analysis | Search for `ThreadLocal` entries in thread-local storage; check `remove()` calls |
| CompletableFuture not completing | Debug with `whenComplete()` | Add `whenComplete()` callbacks to trace completion; check for unhandled exceptions |

## Code Review Checklist

- [ ] Thread pools sized appropriately for workload type (CPU-bound vs I/O-bound)
- [ ] Lock ordering documented and consistent across codebase
- [ ] `volatile` used for flags shared across threads
- [ ] Atomic variables preferred over `synchronized` for simple operations
- [ ] `InterruptedException` properly handled (not swallowed)
- [ ] `ThreadLocal` cleaned up in finally blocks
- [ ] Concurrent collections used for shared state

## Architecture Considerations

Multithreading architecture defines system throughput and responsiveness. At scale, the choice between platform threads, virtual threads (Java 21), and thread pools determines resource utilization. For I/O-bound services, virtual threads eliminate thread pool sizing complexity. For CPU-bound work, fixed-size pools with work-stealing algorithms maximize core utilization.

In distributed systems, thread architecture within each service affects system-wide behavior — thread pool exhaustion in one service causes cascading timeouts. Proper thread isolation (bulkheads) prevents failures from propagating. For message-driven architectures, thread pools for consumers must be sized to handle peak message rates without exhausting resources.

| Pattern | Use Case | Trade-offs |
|---------|----------|------------|
| Fixed thread pool | CPU-bound work | Pros: Predictable resource usage; Cons: Task queuing under load |
| Virtual threads (Java 21) | I/O-bound work | Pros: Millions of threads; Cons: Still learning ecosystem support |
| CompletableFuture composition | Async pipelines | Pros: Non-blocking composition; Cons: Debugging complexity |
| ReadWriteLock | Read-heavy shared state | Pros: Concurrent reads; Cons: Write starvation risk |

## Security Considerations

| Risk | Impact | Mitigation |
|------|--------|------------|
| Race condition in authentication | Bypass security checks | Synchronize critical sections; use atomic operations for auth state |
| Deadlock causing denial of service | Application hangs, unavailable | Use `tryLock()` with timeout; establish lock ordering protocol |
| Thread pool exhaustion | Cascading failure, DoS | Size pools appropriately; implement circuit breakers; add queue limits |
| Sensitive data in ThreadLocal | Data leakage across requests | Remove ThreadLocal in finally blocks; use request-scoped alternatives |
| Unsafe publication of shared objects | Visibility bugs, inconsistent state | Use `volatile`, `final`, or proper synchronization for publication |

## Evolution & Modernization

| Version | Change | Migration Path |
|---------|--------|----------------|
| Java 1.0 | `Thread` class, `Runnable` | Use `Runnable`/`Callable` with ExecutorService |
| Java 5 | `ExecutorService`, `Lock`, `Semaphore` | Replace manual thread creation with thread pools |
| Java 7 | `ForkJoinPool`, `Phaser` | Use for divide-and-conquer and phased computation |
| Java 8 | `CompletableFuture`, parallel streams | Replace callback hell with composition; benchmark parallel streams |
| Java 9 | `Flow` API (reactive streams) | Adopt for backpressure-aware processing |
| Java 21 | Virtual threads (standard) | Evaluate for I/O-bound workloads; replace thread pools where appropriate |

## Version Validation

| Feature | Java Version | Status |
|---------|-------------|--------|
| `ExecutorService` | Java 5 | Stable |
| `CompletableFuture` | Java 8 | Stable |
| `ForkJoinPool` | Java 7 | Stable |
| `Flow` API (reactive streams) | Java 9 | Stable |
| Virtual threads | Java 21 | Stable |
| Structured concurrency | Java 21 | Preview |

## Production Incidents

### Incident 1: Deadlock in Payment Processing System

**Problem:** A payment processing system hung indefinitely under high load, requiring manual restart.
**Cause:** Two threads acquired locks in opposite order: Thread A locked Account then Payment, Thread B locked Payment then Account.
**Impact:** 100% of payment processing stopped; $500K in pending transactions; 4-hour downtime.
**Detection:** Thread dump showed deadlock between two threads; jstack confirmed circular wait.
**Solution:** Established lock ordering protocol; always acquire Account lock before Payment lock; added deadlock detection.
**Prevention:** Document lock ordering; use `tryLock()` with timeout; add deadlock detection monitoring.

### Incident 2: Race Condition in Cache Update

**Problem:** A distributed cache showed stale data for 10% of requests despite cache invalidation.
**Cause:** Cache update used check-then-act pattern without synchronization; two threads updated simultaneously.
**Impact:** Users saw outdated product prices; 5% of orders used incorrect pricing; customer complaints.
**Detection:** Cache inconsistency reports; investigation revealed race condition in update logic.
**Solution:** Used `ConcurrentHashMap.compute()` for atomic check-and-update; added distributed locks for cross-node consistency.
**Prevention:** Use atomic operations for check-then-act; document thread-safety requirements; add concurrency tests.

### Incident 3: Thread Pool Exhaustion Causing Cascading Failure

**Problem:** A microservice became unresponsive under load, causing cascading failures across dependent services.
**Cause:** Fixed thread pool (10 threads) exhausted waiting on downstream service; new requests queued indefinitely.
**Impact:** 3 services failed; 50% of API traffic dropped; 30-minute recovery time.
**Detection:** Thread count at maximum; queue depth increasing; downstream service timeout logs.
**Solution:** Added circuit breaker to fail fast; increased thread pool size; added queue limits with rejection policies.
**Prevention:** Size thread pools based on workload; implement circuit breakers; monitor thread pool metrics.

## Production Checklist

- [ ] Use thread pools instead of creating threads manually
- [ ] Minimize lock scope — hold locks for shortest time possible
- [ ] Use concurrent collections for shared state
- [ ] Prefer atomic variables over synchronized blocks for simple operations
- [ ] Handle interrupts properly — don't swallow `InterruptedException`
- [ ] Use `volatile` for flags accessed across threads
- [ ] Document thread-safety guarantees for each class
- [ ] Add timeout to lock acquisition to prevent deadlocks
- [ ] Monitor thread pool metrics (queue depth, active threads)
- [ ] Test concurrent code with stress tests

## Maturity Levels

| Level | Description |
|-------|-------------|
| Beginner | Creates threads manually; uses `synchronized` everywhere; doesn't understand thread states |
| Intermediate | Uses thread pools; understands synchronization; uses `volatile` and atomics |
| Advanced | Designs thread-safe classes; implements custom concurrent utilities; debugs concurrency issues |
| Expert | Builds concurrent systems; contributes to concurrent libraries; teaches concurrency patterns |

## Common Myths

1. **Myth**: `synchronized` is always the best choice for thread safety
   **Truth**: `synchronized` can cause contention; prefer `volatile`, atomics, or concurrent collections for better performance.

2. **Myth**: Creating more threads always improves performance
   **Truth**: Thread creation is expensive; context switching adds overhead. Use thread pools and size them appropriately.

3. **Myth**: `volatile` is sufficient for atomic operations
   **Truth**: `volatile` ensures visibility but not atomicity; use `Atomic` classes or `synchronized` for compound operations.

4. **Myth**: Virtual threads eliminate all concurrency issues
   **Truth**: Virtual threads improve I/O-bound concurrency but still have race conditions, deadlocks, and other concurrency bugs.

5. **Myth**: ThreadLocal is always safe for per-thread data
   **Truth**: `ThreadLocal` can cause memory leaks in thread pools; values are not cleaned up when threads are reused.

## Related Topics

- [JVM Internals](../10-jvm-internals/README.md)
- [Java Memory Model](../00-knowledge-atoms/java-memory-model/README.md)

## Next

- [JVM Internals](../10-jvm-internals/README.md)

## One-Minute Revision

| Aspect | Value |
|--------|-------|
| Purpose | Concurrent execution |
| Complexity | Varies |
| Thread Safe | Must be implemented |
| Ordered | No (execution order) |
| Allows Null | Yes |
| Best Alternative | Virtual threads (for I/O) |
| When to Use | Parallel processing |
| When to Avoid | Simple sequential code |
