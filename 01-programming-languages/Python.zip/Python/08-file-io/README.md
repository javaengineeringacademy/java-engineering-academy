# Module 08: File I/O

> "File I/O is where your code meets the real world. Do it right, or lose data."

## Why File I/O Matters

Every application eventually needs to persist data, read configuration files, process logs, or exchange data with other systems. File I/O is where your code meets the real world — reading user inputs, writing results, and managing resources that exist beyond your program's memory. Without proper file handling, you'd lose data, corrupt files, and leak file descriptors.

Without understanding file I/O, you'd write code that silently overwrites important data, forgets to close files (leading to resource leaks), or crashes on permission errors. That's why file I/O fundamentals exist — they provide the patterns for safely reading and writing data, managing resources with context managers, and handling the edge cases that cause production incidents.

## Engineering Decision Framework

| Factor | Use This | Consider Alternatives |
|--------|----------|----------------------|
| When to use | Any file operations, config loading, data processing | In-memory operations for small data |
| When NOT to use | Don't forget context managers; don't ignore encoding | Use `with` statement always |
| Alternatives | pathlib for paths, aiofiles for async, pandas for complex CSV | Simple `open()` for basic cases |
| Production Examples | Log processing, config management, data pipelines | Prototypes, quick scripts |
| Common Mistakes | Forgetting encoding, not using atomic writes, resource leaks | Always use `with`; specify encoding |

## What You'll Learn

By the end of this module, you'll be able to:

- Read and write files using Python's built-in functions
- Choose the correct file mode for each use case
- Use context managers to guarantee resource cleanup
- Handle large files efficiently with line-by-line processing
- Work with binary data and file paths using pathlib

---
        process(line)

# Read/write with binary
with open("image.png", "rb") as f:
    data = f.read()

# Write binary
with open("output.png", "wb") as f:
    f.write(image_bytes)
```

### Custom Context Manager

```python
from contextlib import contextmanager

@contextmanager
def managed_resource(name: str):
    """Custom context manager for resource management."""
    print(f"Acquiring {name}")
    resource = {"name": name, "status": "active"}
    try:
        yield resource
    except Exception as e:
        print(f"Error with {name}: {e}")
        resource["status"] = "error"
    finally:
        print(f"Releasing {name}")
        resource["status"] = "released"

with managed_resource("database") as db:
    print(f"Using {db['name']}")
# Acquiring database
# Using database
# Releasing database
```

### Async Context Manager

```python
import aiofiles

async def read_file(path: str) -> str:
    async with aiofiles.open(path, "r") as f:
        return await f.read()
```

---

## Interview Questions

### Q1: What is the difference between text and binary mode?
**Answer:** Text mode handles encoding (UTF-8, ASCII). Binary mode reads raw bytes. Use binary for images, text for strings. Always specify encoding in text mode.

### Q2: What is the `with` statement and why use it?
**Answer:** `with` ensures file is closed even if exception occurs. It's a context manager that calls __enter__ and __exit__. Always use with for file operations.

### Q3: What is the difference between `read()`, `readline()`, and `readlines()`?
**Answer:** read() reads entire file. readline() reads one line. readlines() reads all lines into list. For large files, use iteration (for line in f).

### Q4: What is pathlib and why prefer it over os.path?
**Answer:** pathlib provides object-oriented paths (Path('/home/user/file.txt')). It's more readable, cross-platform, and has methods like .stem, .suffix, .parent.

### Q5: How do you handle encoding errors?
**Answer:** Use errors parameter: 'ignore' (skip bad chars), 'replace' (use ?), 'strict' (raise exception). Always specify encoding='utf-8' explicitly.

---

## pathlib (Modern File Handling)

`pathlib` is the modern, object-oriented way to handle file paths.

```python
from pathlib import Path

# Create path objects
p = Path("data/file.txt")
p = Path.home() / "Documents" / "data.txt"
p = Path("/usr/local/bin/python")

# Path properties
print(p.name)      # "python"
print(p.stem)      # "python" (without extension)
print(p.suffix)    # "" (extension)
print(p.parent)    # "/usr/local/bin"
print(p.exists())  # True/False
print(p.is_file()) # True/False
print(p.is_dir())  # True/False

# Read/write operations
content = p.read_text()              # Read entire file
p.write_text("hello world")         # Write string
data = p.read_bytes()               # Read as bytes
p.write_bytes(b"binary data")       # Write bytes

# Directory operations
p.mkdir(parents=True, exist_ok=True)  # Create dirs recursively
p.rmdir()                              # Remove empty dir
list(p.glob("*.py"))                  # Find Python files
list(p.rglob("*.txt"))                # Recursive search

# Rename/move
p.rename("new_name.txt")
p.unlink()  # Delete file
```

### Path Operations

```python
from pathlib import Path

# Join paths (use / operator)
data_dir = Path("data")
file_path = data_dir / "input" / "file.txt"
# PosixPath('data/input/file.txt')

# Relative paths
root = Path("/usr/local")
relative = root.relative_to("/usr")
# PosixPath('local')

# Suffix changes
p = Path("file.txt")
new_p = p.with_suffix(".csv")
# PosixPath('file.csv')

# Parent traversal
p = Path("/a/b/c/d.txt")
p.parent      # PosixPath('/a/b/c')
p.parent.parent  # PosixPath('/a/b')
```

---

## Reading/Writing Files

### Reading

```python
from pathlib import Path

# Read entire file
content = Path("data.txt").read_text()

# Read line by line (memory efficient)
with open("large_file.txt", "r") as f:
    for line in f:
        process(line.strip())

# Read all lines into list
with open("data.txt", "r") as f:
    lines = f.readlines()  # Includes newline characters

# Read with encoding
with open("data.txt", "r", encoding="utf-8") as f:
    content = f.read()

# Read binary
with open("image.png", "rb") as f:
    data = f.read()
    # Process binary data
```

### Writing

```python
from pathlib import Path

# Write string (overwrites!)
Path("output.txt").write_text("Hello, World!")

# Write with encoding
with open("output.txt", "w", encoding="utf-8") as f:
    f.write("Line 1\n")
    f.write("Line 2\n")
    f.writelines(["Line 3\n", "Line 4\n"])

# Append mode
with open("log.txt", "a") as f:
    f.write("New log entry\n")

# Write binary
with open("output.bin", "wb") as f:
    f.write(b"\x00\x01\x02")

# Atomic write pattern (safe for production)
import tempfile
from pathlib import Path

def atomic_write(path: Path, content: str) -> None:
    """Write atomically — no partial writes on crash."""
    with tempfile.NamedTemporaryFile(
        mode="w", dir=path.parent, delete=False
    ) as tmp:
        tmp.write(content)
        tmp_path = Path(tmp.name)
    tmp_path.rename(path)

atomic_write(Path("data.json"), '{"key": "value"}')
```

---

## CSV, JSON, YAML Handling

### CSV

```python
import csv
from pathlib import Path

# Read CSV
with open("data.csv", "r", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        print(row["name"], row["age"])

# Write CSV
with open("output.csv", "w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=["name", "age"])
    writer.writeheader()
    writer.writerow({"name": "Alice", "age": 30})

# With pandas (recommended for complex CSV)
import pandas as pd
df = pd.read_csv("data.csv")
df.to_csv("output.csv", index=False)
```

### JSON

```python
import json
from pathlib import Path

# Read JSON
data = json.loads(Path("config.json").read_text())

# Write JSON
config = {"host": "localhost", "port": 8080}
Path("config.json").write_text(json.dumps(config, indent=2))

# Pretty print
print(json.dumps(data, indent=2, sort_keys=True))

# Handle errors
try:
    data = json.loads(invalid_json)
except json.JSONDecodeError as e:
    print(f"Invalid JSON: {e}")
```

### YAML

```python
import yaml
from pathlib import Path

# Read YAML
with open("config.yaml") as f:
    config = yaml.safe_load(f)

# Write YAML
config = {"database": {"host": "localhost", "port": 5432}}
with open("config.yaml", "w") as f:
    yaml.dump(config, f, default_flow_style=False)

# Multi-document YAML
with open("documents.yaml") as f:
    docs = list(yaml.safe_load_all(f))
```

---

## Async File I/O

```python
import asyncio
import aiofiles

async def async_read(path: str) -> str:
    async with aiofiles.open(path, "r") as f:
        return await f.read()

async def async_write(path: str, content: str) -> None:
    async with aiofiles.open(path, "w") as f:
        await f.write(content)

async def process_files(paths: list[str]) -> list[str]:
    """Read multiple files concurrently."""
    tasks = [async_read(path) for path in paths]
    return await asyncio.gather(*tasks)

# Run it
results = asyncio.run(process_files(["file1.txt", "file2.txt"]))
```

### When to Use Async I/O

- Reading many small files (network or disk)
- Web servers handling file uploads/downloads
- Background file processing
- Any I/O-bound operation that can be parallelized

### When NOT to Use Async I/O

- Single file operations (overhead not worth it)
- CPU-bound processing after reading
- Simple scripts (synchronous is clearer)

---

## When to Use Which Approach

| Scenario | Recommended | Why |
|----------|-------------|-----|
| Simple config file | `Path.read_text()` + `json.loads()` | Clean, modern |
| Large file processing | `open()` + line iteration | Memory efficient |
| Complex CSV/data | `pandas` | Powerful data manipulation |
| Binary files | `open("rb")` | Direct binary access |
| Many files concurrently | `aiofiles` | Parallel I/O |
| Production writes | Atomic write pattern | Prevents data corruption |
| Path manipulation | `pathlib.Path` | Object-oriented, cross-platform |

---

## Production Incidents

### Incident 1: Encoding Error Corrupting User Data

**Problem:** User uploaded file with special characters got corrupted
**Cause:** File read without specifying encoding; Windows default was not UTF-8
**Impact:** 50 user uploads corrupted; manual data recovery required
**Detection:** Users reported missing characters in uploaded files
**Solution:**
```python
# BAD: No encoding specified
with open("user_data.txt") as f:
    content = f.read()

# GOOD: Explicit UTF-8 encoding
with open("user_data.txt", "r", encoding="utf-8") as f:
    content = f.read()
```
**Prevention:** Always specify `encoding="utf-8"`; add linting rule to catch missing encoding; use pathlib

### Incident 2: File Descriptor Leak Under Load

**Problem:** Service failed to open new files after 1000 requests
**Cause:** `open()` without context manager; file descriptors not closed on exception
**Impact:** "Too many open files" error; service degradation
**Detection:** `ulimit -n` showed file descriptor exhaustion
**Solution:**
```python
# BAD: Manual close
f = open("data.txt")
try:
    data = f.read()
finally:
    f.close()  # May not execute on certain exceptions

# GOOD: Context manager
with open("data.txt") as f:
    data = f.read()
```
**Prevention:** Always use `with` statement; use `resource.setrlimit` to monitor; add file descriptor monitoring

### Incident 3: Non-Atomic Write Causing Partial Data

**Problem:** JSON config file corrupted after crash during write
**Cause:** `json.dump()` wrote directly to target file; crash left partial content
**Impact:** Service couldn't restart; required manual config recovery
**Detection:** Service startup failed with JSONDecodeError
**Solution:**
```python
import tempfile
from pathlib import Path

def atomic_write(path: Path, content: str) -> None:
    with tempfile.NamedTemporaryFile(
        mode="w", dir=path.parent, delete=False
    ) as tmp:
        tmp.write(content)
        tmp_path = Path(tmp.name)
    tmp_path.rename(path)  # Atomic on most filesystems
```
**Prevention:** Use atomic writes for critical files; write to temp file then rename; backup before write

## Production Checklist

- [ ] **Use context managers** — Never forget to close files
- [ ] **Use pathlib** — Modern, cross-platform path handling
- [ ] **Handle encoding** — Always specify `encoding="utf-8"` for text
- [ ] **Atomic writes** — Use temp files + rename for critical data
- [ ] **Validate file existence** — Check `Path.exists()` before operations
- [ ] **Use appropriate buffer size** — Large files: larger buffer; small files: smaller
- [ ] **Handle binary vs text** — Use `rb`/`wb` for binary, `r`/`w` for text
- [ ] **Exception handling** — Catch `FileNotFoundError`, `PermissionError`, `IsADirectoryError`
- [ ] **Log file operations** — Track opens, closes, errors
- [ ] **Test file cleanup** — Use `tempfile` for test fixtures

```python
# Production pattern
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

def read_config(path: Path) -> dict:
    """Read and parse config file with error handling."""
    if not path.exists():
        raise FileNotFoundError(f"Config not found: {path}")
    if not path.is_file():
        raise IsADirectoryError(f"Expected file: {path}")

    try:
        content = path.read_text(encoding="utf-8")
        return json.loads(content)
    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON in {path}: {e}")
        raise
```

---

## Maturity Levels

| Level | What It Looks Like | Indicators |
|-------|-------------------|------------|
| **Beginner** | `open()` without context manager | Resource leaks on exceptions |
| **Basic** | `with open()` | Correct cleanup, basic operations |
| **Intermediate** | `pathlib` + context managers | Modern, cross-platform code |
| **Advanced** | Async I/O + atomic writes | Production-ready, concurrent processing |
| **Expert** | Custom context managers + error recovery | Self-healing file operations |

### Progression Path

1. **Start:** Always use `with` statement
2. **Then:** Switch to `pathlib` for all path operations
3. **Then:** Add proper encoding and error handling
4. **Then:** Use async I/O for concurrent file operations
5. **Finally:** Implement atomic writes and self-healing patterns

---

## Common Myths

**Myth: "Text files don't need encoding specified"**
> Reality: The default encoding varies by platform. Always specify `encoding="utf-8"` to ensure portability.

**Myth: "pathlib is slower than os.path"**
> Reality: Negligible difference in most cases. The clarity and safety of pathlib far outweigh any micro-optimization.

**Myth: "Buffering always improves performance"**
> Reality: For small files, default buffering is fine. For large files, explicit buffering helps. For network I/O, buffering can be critical. Measure first.

**Myth: "readlines() is the standard way to read files"**
> Reality: Iterating directly over the file object is more memory efficient — it reads line by line without loading the entire file.

**Myth: "File operations are atomic"**
> Reality: They're NOT. A crash during write can corrupt data. Use atomic write patterns (temp file + rename) for critical data.

---

## Related Topics

- [01-fundamentals](../01-fundamentals/) - String handling and encoding
- [13-logging](../13-logging/) - File-based logging
- [18-senior](../18-senior/) - Production file handling patterns

## One-Minute Revision

- **Always use context managers** — `with open(...)` guarantees cleanup
- **Use pathlib** — `Path("file.txt").read_text()` over `open("file.txt")`
- **Specify encoding** — `encoding="utf-8"` for all text operations
- **File modes matter** — `w` truncates silently, `a` appends, `r+` reads+writes
- **Read large files line by line** — Don't load entire file into memory
- **Atomic writes** — Temp file + rename for data safety
- **CSV:** Use `csv.DictReader` or `pandas` for complex data
- **JSON:** `json.loads()` / `json.dumps()` with `indent=2`
- **YAML:** Always use `yaml.safe_load()` (not `yaml.load()`)
- **Async I/O:** For concurrent file operations, use `aiofiles`
- **Error handling:** Catch `FileNotFoundError`, `PermissionError`, `JSONDecodeError`

---

## Debugging Tips

| Problem | Tool/Technique | How |
|---------|---------------|-----|
| File descriptor leak under load | `ulimit -n` and `lsof` inspection | Always use `with` statement; add file descriptor monitoring |
| Encoding error corrupting data | `sys.getdefaultencoding()` check | Always specify `encoding="utf-8"`; add linting rule |
| Non-atomic write causing partial data | Write to temp file + rename | Use `tempfile.NamedTemporaryFile` + `Path.rename()` for atomic writes |
| `PermissionError` on file operations | Check file permissions with `os.stat()` | Validate file permissions before operations; handle gracefully |
| CSV parsing error with special characters | `csv.Sniffer` to detect dialect | Specify `newline=""` in `open()`; use `csv.QUOTE_ALL` for safety |

## Code Review Checklist

- [ ] Context managers (`with`) used for ALL file operations
- [ ] `encoding="utf-8"` specified in all text file operations
- [ ] Atomic writes used for critical data (temp file + rename)
- [ ] `pathlib.Path` used instead of `os.path` for path manipulation
- [ ] File existence validated before read/write operations
- [ ] Binary mode (`rb`/`wb`) used for non-text files
- [ ] `json.load()` and `yaml.safe_load()` used for parsing (not `eval`)

## Architecture Considerations

File I/O is the bridge between application state and persistent storage. Atomic writes prevent data corruption on crashes. Encoding handling ensures cross-platform compatibility. Context managers guarantee resource cleanup. The choice between sync and async I/O depends on whether file operations are in the critical path.

| Pattern | Use Case | Trade-offs |
|---------|----------|------------|
| Atomic write (temp + rename) | Critical configuration files | Safe but adds complexity |
| `pathlib.Path` for all paths | Cross-platform path handling | Modern and readable but slower than `os.path` |
| Async file I/O with `aiofiles` | Concurrent file operations | Scalable but adds async complexity |

## Security Considerations

| Risk | Impact | Mitigation |
|------|--------|------------|
| Path traversal allowing arbitrary file access | Reading/writing sensitive files | Validate paths with `pathlib`; restrict to allowed directories |
| Unsafe YAML `load()` enabling code execution | Remote code execution | Always use `yaml.safe_load()`; never use `yaml.load()` with untrusted input |
| File descriptor leak exposing sensitive files | Resource exhaustion or data leak | Use context managers; close files explicitly on error |

## Evolution & Modernization

| Version | Change | Migration Path |
|---------|--------|----------------|
| Python 3.6+ | `pathlib.Path` improvements | Replace `os.path` with `pathlib` for all path operations |
| Python 3.8+ | `fspath` protocol | Use `os.fspath()` for path-like objects |
| Python 3.12+ | Improved `pathlib` features | Use `Path.walk()` instead of `os.walk()` |

## Version Validation

| Feature | Python Version | Status |
|---------|---------------|--------|
| `pathlib.Path` | 3.4+ | Stable, preferred over `os.path` |
| `aiofiles` (third-party) | 3.4+ | Stable, async file I/O |
| `json.loads()` | 2.6+ | Stable, JSON parsing |
| `yaml.safe_load()` | Third-party | Stable, safe YAML parsing |
